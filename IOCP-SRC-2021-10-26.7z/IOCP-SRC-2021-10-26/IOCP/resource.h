//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by IOCP.rc
//
#define IDD_IOCP_DIALOG                 102
#define IDD_SETTINGS                    103
#define IDR_MAINFRAME                   128
#define IDB_HEADER                      129
#define IDD_TESTAUDIO_DIALOG            130
#define IDR_MENU1                       131
#define IDR_TRAY_MENU                   131
#define IDB_OKD                         133
#define IDB_OKU                         134
#define IDB_STRTU                       135
#define IDB_STRTX                       136
#define IDB_PLAYU                       137
#define IDB_PLAYX                       138
#define IDB_STRTD                       139
#define IDB_PLAYD                       141
#define IDC_CLIENTLIST                  1000
#define IDC_ADRESS                      1001
#define IDC_BUTTON1                     1002
#define IDC_SENDFILE                    1002
#define IDC_DISCONNECTALL               1003
#define IDC_DISCONNECT                  1004
#define IDC_SEND                        1005
#define IDC_RANDOMDISCONNECT            1006
#define IDC_SENDTXT                     1007
#define IDC_EDITSTATUS                  1007
#define IDC_RECEIVEDTXT                 1008
#define IDC_FLOOD                       1009
#define IDC_LOGG                        1010
#define IDC_MSGPERSEC                   1011
#define IDC_STOPSTART                   1012
#define IDC_Settings                    1013
#define IDC_SENDFILE2                   1014
#define IDC_PORTNR                      1016
#define IDC_MAXNUMOFCONNECTION          1017
#define IDC_NROFIOWORKERS               1018
#define IDC_NROFLOGICWORKERS            1019
#define IDC_NROFFREEBUFF                1020
#define IDC_NROFFREECONTEXT             1021
#define IDC_NRPENDLINGREAD              1022
#define IDC_RECEIVEDORDERED             1023
#define IDC_SENDORDERED                 1024
#define IDC_COMBO_DEVICES               1030
#define IDC_BUTTON_PLAYSINE             1031
#define IDC_BUTTON_PLAY                 1031
#define IDC_BUTTON_PLAY16               1032
#define IDC_BUTTON_PLAY8                1033
#define IDC_BUTTON_PAUSE                1034
#define IDC_BUTTON_PLAYPAUSE            1034
#define IDC_BUTTON_CONTINUE             1035
#define IDC_BUTTON_PLAYCONTINUE         1035
#define IDC_BUTTON_RECORD               1036
#define IDC_BUTTON_STOPREC              1037
#define IDC_BUTTON_PLAYSTOP             1037
#define IDC_BUTTON_RECPAUSE             1038
#define IDC_BUTTON_RECCONTINUE          1039
#define IDC_BUTTON_RECSTOP              1040
#define IDC_RICHEDIT1                   1040
#define IDC_FILENAME                    1041
#define IDC_CHANGEFILE                  1042
#define ID_MENU_EXIT                    32771
#define ID_MENU_RESTORE                 32772

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32773
#define _APS_NEXT_CONTROL_VALUE         1008
#define _APS_NEXT_SYMED_VALUE           104
#endif
#endif
