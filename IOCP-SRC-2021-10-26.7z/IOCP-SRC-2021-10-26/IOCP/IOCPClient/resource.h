//{{NO_DEPENDENCIES}}
// Microsoft Visual C++ generated include file.
// Used by IOCPClient.rc
//
#define IDS_TEST                        1
#define IDR_MAINFRAME                   7
#define IDD_IOCPCLIENT_DIALOG           102
#define IDB_HEADER                      130
#define IDD_SETTINGS                    131
#define IDR_TRAY_MENU                   132
#define IDI_ICON1                       139
#define IDC_CLIENTLIST                  1000
#define IDC_ADRESS                      1001
#define IDC_CONNECT                     1002
#define IDC_DISCONNECTALL               1003
#define IDC_DISCONNECT                  1004
#define IDC_SEND                        1005
#define IDC_SENDTXT                     1007
#define IDC_RECEIVEDTXT                 1008
#define IDC_FLOOD                       1009
#define IDC_LOGG                        1010
#define IDC_MSGPERSEC                   1011
#define IDC_STOPSTART                   1012
#define IDC_Settings                    1013
#define IDC_NICKNAME                    1014
#define IDC_PORTNR                      1016
#define IDC_MAXNUMOFCONNECTION          1017
#define IDC_NROFIOWORKERS               1018
#define IDC_NROFLOGICWORKERS            1019
#define IDC_NROFFREEBUFF                1020
#define IDC_NROFFREECONTEXT             1021
#define IDC_NRPENDLINGREAD              1022
#define IDC_RECEIVEDORDERED             1023
#define IDC_SENDORDERED                 1024
#define IDC_DOWNLOADPATH                1025
#define IDC_EDIT1                       1026
#define IDC_PORT                        1026
#define IDC_AUTORECONNECT               1027
#define ID_MENU_RESTORE                 32771

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        142
#define _APS_NEXT_COMMAND_VALUE         32771
#define _APS_NEXT_CONTROL_VALUE         1028
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
